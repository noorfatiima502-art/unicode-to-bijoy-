<?php
/**
 * Plugin Name: Ultimate Bangla Converter
 * Plugin URI:  #
 * Description: An ultimate Unicode to Bijoy and Bijoy to Unicode conversion tool with pristine accuracy, file/voice support, and automatic mode switching.
 * Version:     1.0.0
 * Author:      Your Name
 * License:     GPL-2.0+
 */

// Prevent direct file access
if (!defined('ABSPATH')) {
    exit;
}

// Function to enqueue necessary scripts and styles
function sbc_enqueue_assets() {
    // CSS
    wp_enqueue_style('sbc-font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css', array(), '6.4.0');
    wp_enqueue_style('sbc-inter-font', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap', array(), null);
    wp_enqueue_style('sbc-main-style', plugin_dir_url(__FILE__) . 'assets/css/style.css', array(), '1.1.0');

    // JS
    wp_enqueue_script('sbc-mammoth', plugin_dir_url(__FILE__) . 'assets/js/mammoth.min.js', array(), '1.0.0', true);
    wp_enqueue_script('sbc-common', plugin_dir_url(__FILE__) . 'assets/js/common.js', array(), '1.0.0', true);
    wp_enqueue_script('sbc-bijoy2uni', plugin_dir_url(__FILE__) . 'assets/js/bijoy2uni.js', array(), '1.0.0', true);
    wp_enqueue_script('sbc-uni2bijoy', plugin_dir_url(__FILE__) . 'assets/js/uni2bijoy.js', array(), '1.0.0', true);
    wp_enqueue_script('sbc-core-converter', plugin_dir_url(__FILE__) . 'assets/js/core-converter.js', array(), '1.0.0', true);
    wp_enqueue_script('sbc-main-script', plugin_dir_url(__FILE__) . 'assets/js/script.js', array('sbc-mammoth'), '1.1.0', true);
}
add_action('wp_enqueue_scripts', 'sbc_enqueue_assets');

// Function to render the shortcode
function sbc_render_converter() {
    ob_start();
    ?>
    <div class="converter-wrapper">
        <div class="converter-card" id="converter-card">
            <div class="panels">
                <!-- Left Panel -->
                <div class="panel">
                    <div class="panel-header">
                        <h3 id="left-title" style="margin: 0; font-size: 18px; color: #ffffff; font-weight: 600;">Unicode Input</h3>
                    </div>
                    <div class="textarea-wrapper">
                        <textarea id="input-text" placeholder="Type or paste your text here..." spellcheck="false"></textarea>
                        <button class="mic-btn" id="mic-btn" title="Start Voice Typing">
                            <i class="fas fa-microphone"></i>
                        </button>
                    </div>
                    <div class="panel-footer" style="justify-content: center; background-color: #f0fdf2; border-top: 1px solid #dcfce7;">
                        <button class="action-badge borderless-btn" onclick="document.getElementById('file-upload').click()">
                            <i class="fas fa-file-upload"></i> Upload File
                        </button>
                        <input type="file" id="file-upload" accept=".txt,.doc,.docx" style="display: none;">
                    </div>
                </div>

                <!-- Swap Button -->
                <div class="swap-wrapper">
                    <button class="swap-btn" id="swap-btn" title="Swap Conversion Direction">
                        <i class="fas fa-exchange-alt"></i>
                    </button>
                </div>

                <!-- Right Panel -->
                <div class="panel">
                    <div class="panel-header">
                        <h3 id="right-title" style="margin: 0; font-size: 18px; color: #ffffff; font-weight: 600;">Bijoy Output</h3>
                    </div>
                    <div class="textarea-wrapper">
                        <textarea id="output-text" placeholder="Converted text will appear here..." readonly spellcheck="false"></textarea>
                    </div>
                    <div class="panel-footer" style="justify-content: center; background-color: #f0fdf2; border-top: 1px solid #dcfce7;">
                        <button id="download-btn" class="action-badge borderless-btn" title="Download Output">
                            <i class="fas fa-file-download"></i> Download File
                        </button>
                    </div>
                </div>
            </div>

            <!-- Controls -->
            <div class="controls">
                <button id="btn-u2b" class="btn btn-conversion active">Unicode &rarr; Bijoy</button>
                <button id="btn-b2u" class="btn btn-conversion">Bijoy &rarr; Unicode</button>
                <button id="btn-copy" class="btn btn-copy"><i class="fas fa-copy"></i> Copy</button>
                <button id="btn-clear" class="btn btn-clear"><i class="fas fa-trash"></i> Clear</button>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

// Register the shortcode [ultimate_bangla_converter]
add_shortcode('ultimate_bangla_converter', 'sbc_render_converter');
