<?php
/**
 * Plugin Name: Bangla Converter Shortcode
 * Description: A powerful Unicode to Bijoy and Bijoy to Unicode converter. Use shortcode [bangla_converter] anywhere on your site.
 * Version: 1.0.0
 * Author: Tool Builder
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Enqueue Scripts and Styles
function enqueue_bangla_converter_assets() {
    global $post;
    // Only load if the shortcode is on the page
    if ( is_a( $post, 'WP_Post' ) && has_shortcode( $post->post_content, 'bangla_converter') ) {
        // Enqueue Google Fonts
        wp_enqueue_style('bangla-converter-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap', array(), null);
        
        // Enqueue FontAwesome
        wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css', array(), '6.4.0');
        
        // Enqueue Custom CSS
        wp_enqueue_style('bangla-converter-style', plugin_dir_url(__FILE__) . 'assets/style.css', array(), '1.0.0');

        // Enqueue Scripts
        wp_enqueue_script('mammoth-js', plugin_dir_url(__FILE__) . 'assets/mammoth.min.js', array(), '1.0.0', true);
        wp_enqueue_script('bangla-common-js', plugin_dir_url(__FILE__) . 'assets/common.js', array(), 'mammoth-js', '1.0.0', true);
        wp_enqueue_script('bangla-bijoy2uni-js', plugin_dir_url(__FILE__) . 'assets/bijoy2uni.js', array(), '1.0.0', true);
        wp_enqueue_script('bangla-uni2bijoy-js', plugin_dir_url(__FILE__) . 'assets/uni2bijoy.js', array(), '1.0.0', true);
        wp_enqueue_script('bangla-core-converter-js', plugin_dir_url(__FILE__) . 'assets/core-converter.js', array(), '1.0.0', true);
        wp_enqueue_script('bangla-script-js', plugin_dir_url(__FILE__) . 'assets/script.js', array('bangla-core-converter-js'), '1.0.0', true);
    }
}
add_action('wp_enqueue_scripts', 'enqueue_bangla_converter_assets');

// Shortcode to display the converter
function render_bangla_converter_shortcode() {
    ob_start();
    ?>
    <div class="converter-wrapper">
        <div class="converter-card" id="converter-card">
            <div class="panels">
                <!-- Left Panel -->
                <div class="panel">
                    <div class="panel-header">
                        <h3 id="left-title" style="margin: 0; font-size: 18px; color: #ffffff; font-weight: 600;">Unicode Input</h3>
                    </div>
                    <div class="textarea-wrapper">
                        <textarea id="input-text" placeholder="Type or paste your text here..." spellcheck="false"></textarea>
                        <button class="mic-btn" id="mic-btn" title="Start Voice Typing">
                            <i class="fas fa-microphone"></i>
                        </button>
                    </div>
                    <div class="panel-footer" style="justify-content: center; background-color: #f0fdf2; border-top: 1px solid #dcfce7;">
                        
                        <button class="action-badge borderless-btn" onclick="document.getElementById('file-upload').click()"><i class="fas fa-file-upload"></i> Upload File</button><input type="file" id="file-upload" accept=".txt,.doc,.docx" style="display: none;">
                    </div>
                </div>

                <!-- Swap Button -->
                <div class="swap-wrapper">
                    <button class="swap-btn" id="swap-btn" title="Swap Conversion Direction">
                        <i class="fas fa-exchange-alt"></i>
                    </button>
                </div>

                <!-- Right Panel -->
                <div class="panel">
                    <div class="panel-header">
                        <h3 id="right-title" style="margin: 0; font-size: 18px; color: #ffffff; font-weight: 600;">Bijoy Output</h3>
                    </div>
                    <div class="textarea-wrapper">
                        <textarea id="output-text" placeholder="Converted text will appear here..." readonly spellcheck="false"></textarea>
                    </div>
                    <div class="panel-footer" style="justify-content: center; background-color: #f0fdf2; border-top: 1px solid #dcfce7;">
                        
                        <button id="download-btn" class="action-badge borderless-btn" title="Download Output">
                            <i class="fas fa-file-download"></i> Download File
                        </button>
                    </div>
                </div>
            </div>

            <!-- Controls -->
            <div class="controls">
                <button id="btn-u2b" class="btn btn-conversion active">Unicode &rarr; Bijoy</button>
                <button id="btn-b2u" class="btn btn-conversion">Bijoy &rarr; Unicode</button>
                <button id="btn-copy" class="btn btn-copy"><i class="fas fa-copy"></i> Copy</button>
                <button id="btn-clear" class="btn btn-clear"><i class="fas fa-trash"></i> Clear</button>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('bangla_converter', 'render_bangla_converter_shortcode');
